(function() {
	'use strict';

	angular
		.module('core', ['ngMaterial', 'ngMessages', 'ngAnimate', 'ngAria', 'ngMdIcons']);
})();