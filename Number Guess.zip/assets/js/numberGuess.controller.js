(function() {
	'use strict';

	angular
		.module('numberGuess', ['core'])
		.controller('NumberGuessController', NumberGuessController);

	NumberGuessController.$inject = [];

	function NumberGuessController() {
		var vm = this;
		vm.answer = 0;
		vm.name = '';
		vm.numbers = getNumbers();
		vm.proceedToFirst = proceedToFirst;
		vm.proceedToSecond = proceedToSecond;
		vm.proceedToThird = proceedToThird;
		vm.proceedToFourth = proceedToFourth;
		vm.proceedToFifth = proceedToFifth;
		vm.proceedToAnswer = proceedToAnswer;
		vm.restartGame = restartGame;
		vm.status = 'entername';
		vm.submitname = submitname;
		vm.title = 'Hello World';

		function submitname() {
			if(vm.nameForm.$valid) {
				console.log('valid');
			}
			vm.status = 'intro';
		}

		function proceedToFirst() {
			vm.status = 'first';
		}

		function proceedToSecond(str) {
			if(str === 'yes') {
				vm.answer = vm.answer + 1;
			}
			vm.status = 'second';
		}

		function proceedToThird(str) {
			if(str === 'yes') {
				vm.answer = vm.answer + 2;
			}
			vm.status = 'third';
		}

		function proceedToFourth(str) {
			if(str === 'yes') {
				vm.answer = vm.answer + 4;
			}
			vm.status = 'fourth';
		}

		function proceedToFifth(str) {
			if(str === 'yes') {
				vm.answer = vm.answer + 8;
			}
			vm.status = 'fifth';
		}

		function proceedToAnswer(str) {
			if(str === 'yes') {
				vm.answer = vm.answer + 16;
			}
			vm.status = 'answer';
		}

		function restartGame() {
			vm.name = '';
			vm.answer = 0;
			vm.status = 'entername';
		}

		function getNumbers() {
			return {
				one: {
					first: 1, second: 3, third: 5, 
					fourth: 7, fifth: 9, sixth: 11, 
					seventh: 13, eighth: 15, ninth: 17, 
					tenth: 19, eleventh: 21, twelfth: 23, 
					thirteenth: 25, fourteenth: 27, fifteenth: 29
				},
				two: {
					first: 2, second: 3, third: 6, 
					fourth: 7, fifth: 10, sixth: 11, 
					seventh: 14, eighth: 15, ninth: 18, 
					tenth: 19, eleventh: 22, twelfth: 23, 
					thirteenth: 26, fourteenth: 27, fifteenth: 30
				},
				three: {
					first: 4, second: 5, third: 6, 
					fourth: 7, fifth: 12, sixth: 13, 
					seventh: 14, eighth: 15, ninth: 20, 
					tenth: 21, eleventh: 22, twelfth: 23, 
					thirteenth: 28, fourteenth: 29, fifteenth: 30
				},
				four: {
					first: 8, second: 9, third: 10, 
					fourth: 11, fifth: 12, sixth: 13, 
					seventh: 14, eighth: 15, ninth: 24, 
					tenth: 25, eleventh: 26, twelfth: 27, 
					thirteenth: 28, fourteenth: 29, fifteenth: 30,
				},
				five: {
					first: 16, second: 17, third: 18, 
					fourth: 19, fifth: 20, sixth: 21, 
					seventh: 22, eighth: 23, ninth: 24, 
					tenth: 25, eleventh: 26, twelfth: 27, 
					thirteenth: 28, fourteenth: 29, fifteenth: 30,
				}
			};
		}
	}
})();